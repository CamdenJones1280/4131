//event listener for nav bar buttons
document.getElementById("toggleRecent").addEventListener("click", toggle_recent);
document.getElementById("toggleLikes").addEventListener("click", toggle_likes);
document.getElementById("back_page").addEventListener("click", back_page);
document.getElementById("forward_page").addEventListener("click", forward_page);
document.getElementById("signout").addEventListener("click", sign_out); 

async function sign_out(){
    //causes the main page to redirect to the sign in page and signs user out
    window.location.replace("http://localhost:4131/signout");
}

async function toggle_recent(){
    //causes the main page to refirect to a main page with recent posts showing
    localStorage.setItem("arrangement", "recent");
    localStorage.setItem("page", 0);
    window.location.replace("http://localhost:4131/main?arrangement=recent&page=0");
}

async function toggle_likes(){
    //causes the main page to refirect to a main page with liked posts showing
    localStorage.setItem("arrangement", "liked");
    localStorage.setItem("page", 0);
    window.location.href = "http://localhost:4131/main?arrangement=liked&page=0";
}

async function back_page(){
    let redirectPath = "http://localhost:4131/main?arrangement=";
    let currentPage = localStorage.getItem("page");
    if(currentPage-1 < 0){
        redirectPath = redirectPath + localStorage.getItem("arrangement") + "&page=0";
        window.location.href = redirectPath;
    }else{
        let dec = parseInt(localStorage.getItem("page")) - 1;
        localStorage.setItem("page", dec);
        redirectPath = redirectPath + localStorage.getItem("arrangement") + "&page=" + localStorage.getItem("page");
        window.location.href = redirectPath;
    }
}

async function forward_page(){
    let redirectPath = "http://localhost:4131/main?arrangement=";
    let inc = parseInt(localStorage.getItem("page")) + 1;
    localStorage.setItem("page", inc);
    redirectPath = redirectPath + localStorage.getItem("arrangement") + "&page=" + localStorage.getItem("page");
    window.location.href = redirectPath;
}
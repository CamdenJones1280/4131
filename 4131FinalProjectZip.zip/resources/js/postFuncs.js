//calls the delete post api
async function delPost(ID){
    await fetch("http://localhost:4131/api/delete", {
        method: "DELETE", 
        headers: {"Content-Type": "application/json"}, 
        body: JSON.stringify({"id" : ID})});
        window.location.replace("http://localhost:4131/main");
}

//calls like changing api
async function changePostLikes(ID, option){
    //increments post likes and dislikes through api
    await fetch("http://localhost:4131/api/likes", {
        method: "POST", 
        headers: {"Content-Type": "application/json"}, 
        body: JSON.stringify({"id" : ID, "option" : option})});
}

//calls post editing api
async function editPostMessage(ID){
    //causes database to change the message of a post through api
    let mes = document.getElementById("editedPostMes").value
    await fetch("http://localhost:4131/api/editPost", {
        method: "POST", 
        headers: {"Content-Type": "application/json"}, 
        body: JSON.stringify({"id" : ID, "message" : mes})});
        window.location.replace("http://localhost:4131/viewPage?post=" + ID);
}

//these functions redirect the page to pass the post id as a query and load the proper page
async function viewPost(ID){
    window.location.replace("http://localhost:4131/viewPage?post=" + ID);
}

async function editPost(ID){
    window.location.replace("http://localhost:4131/editPage?post=" + ID);
}